﻿using EasyPay_Task_Transactions.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EasyPay_Task_Transactions.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TransactionController : ControllerBase
    {
       // private readonly TransactionContext _dbContext;

        private readonly ITransactionsRepository _repository;

        public TransactionController(ITransactionsRepository repository)
        {
            _repository = repository;
        }
        // Endpoints  , create  getall , get , post , delete , gettotal

        //GetAll Transactions
        // Get all transactions

        // POST: api/transacations
        [HttpPost]
        public IActionResult AddTransactions([FromBody] Transaction transaction)
        {
            _repository.Add(transaction);
            return CreatedAtAction(nameof(GetTransaction), new { id = transaction.TransactionId }, transaction);
        }

        // GET: api/customers/{id}
        [HttpGet("{id}")]
        public ActionResult<Transaction> GetTransaction(int id)
        {
            var transaction = _repository.Get(id);
            if (transaction == null)
            {
                return NotFound();
            }
            return transaction;

        }
        //update transactions
        [HttpPut("{id}")]
        public IActionResult UpdateTransaction(int id, [FromBody] Transaction updatedTransaction)
        {
            if (id != updatedTransaction.TransactionId)
            {
                return BadRequest("The ID in the URL does not match the ID in the request body.");
            }

            var existingTransaction = _repository.Get(id);
            if (existingTransaction == null)
            {
                return NotFound("Customer not found.");
            }

            // Optionally, you can use automapper or manually update only the necessary properties
            existingTransaction.Amount = updatedTransaction.Amount;
            existingTransaction.TransactionType = updatedTransaction.TransactionType;
            existingTransaction.TransactionDate = updatedTransaction.TransactionDate;
            existingTransaction.Description = updatedTransaction.Description;

            existingTransaction.TransactionDate = updatedTransaction.TransactionDate;

            existingTransaction.Status = updatedTransaction.Status;

            existingTransaction.CustomerFullName = updatedTransaction.CustomerFullName;

            existingTransaction.CustomerAddress = updatedTransaction.CustomerAddress;
            existingTransaction.CustomerPhoneNumber = updatedTransaction.CustomerPhoneNumber;

            _repository.Update(existingTransaction);

            return NoContent();
        }


        // DELETE: api/customers/{id}
        [HttpDelete("{id}")]
        public IActionResult DeleteTransaction(int id)
        {
            var trasaction = _repository.Get(id);
            if (trasaction == null)
            {
                return NotFound();
            }

            _repository.Delete(id);
            return NoContent();
        }

        // List All Transactions
        [HttpGet("all")]
        public ActionResult<IEnumerable<Transaction>> ListAllTransaction()
        {
            return Ok(_repository.ListAll());
        }
      
        // GET: api/transactions/filtered

        [HttpGet("filtered")]
        public ActionResult<IEnumerable<Transaction>> ListAllTransactionwithFilters(
    [FromQuery] string transactionType = null,
    [FromQuery] DateTime? startDate = null,
    [FromQuery] DateTime? endDate = null,
    [FromQuery] string status = null,
    [FromQuery] string customerFullName = null,
    [FromQuery] decimal? minAmount = null,
    [FromQuery] decimal? maxAmount = null)
        {
            var transactions = _repository.ListAll();

            if (!string.IsNullOrEmpty(transactionType))
            {
                transactions = transactions.Where(t => t.TransactionType.Equals(transactionType, StringComparison.OrdinalIgnoreCase)).ToList();
            }

            if (startDate.HasValue)
            {
                transactions = transactions.Where(t => t.TransactionDate >= startDate.Value).ToList();
            }

            if (endDate.HasValue)
            {
                transactions = transactions.Where(t => t.TransactionDate <= endDate.Value).ToList();
            }

            if (!string.IsNullOrEmpty(status))
            {
                transactions = transactions.Where(t => t.Status.Equals(status, StringComparison.OrdinalIgnoreCase)).ToList();
            }

            if (!string.IsNullOrEmpty(customerFullName))
            {
                transactions = transactions.Where(t => t.CustomerFullName.Contains(customerFullName, StringComparison.OrdinalIgnoreCase)).ToList();
            }

            if (minAmount.HasValue)
            {
                transactions = transactions.Where(t => t.Amount >= minAmount.Value).ToList();
            }

            if (maxAmount.HasValue)
            {
                transactions = transactions.Where(t => t.Amount <= maxAmount.Value).ToList();
            }

            if (!transactions.Any())
            {
                return NotFound("No transactions found matching the specified criteria.");
            }

            return Ok(transactions);
        }

        [HttpGet("summary")]
        public ActionResult GetTransactionSummary([FromQuery] string customerFullName)
        {
            var transactions = string.IsNullOrEmpty(customerFullName) ?
                               _repository.ListAll() :
                               _repository.GetTransactionsByCustomer(customerFullName);

            if (transactions == null || !transactions.Any())
            {
                return NotFound("No transactions found for the given customer.");
            }

            var totalTransactions = transactions.Count();
            var totalCredits = transactions.Where(t => t.TransactionType == "Credit").Sum(t => t.Amount);
            var totalDebits = transactions.Where(t => t.TransactionType == "Debit").Sum(t => t.Amount);
            var netBalance = totalCredits - totalDebits;

            var summary = new
            {
                TotalTransactions = totalTransactions,
                TotalCredits = totalCredits,
                TotalDebits = totalDebits,
                NetBalance = netBalance
            };

            return Ok(summary);
        }

    }
}

