﻿using Microsoft.EntityFrameworkCore;
using static EasyPay_Task_Transactions.TransactionRepository;
using System;
using EasyPay_Task_Transactions.Models;

namespace EasyPay_Task_Transactions
{
  

        public class TransactionRepository : ITransactionsRepository
        {
            private readonly TransactionContext _context;

        public TransactionRepository(TransactionContext context)
        {
            _context = context;
        }


        IEnumerable<Transaction> ITransactionsRepository.ListAll()
        {
            return _context.Transactions.ToList();
        }

        public void Update(Transaction transaction)
        {
            _context.Entry(transaction).State = EntityState.Modified;
            _context.SaveChanges();
        }

        //public void Add(Transaction transaction)
        //{
        //    _context.Transactions.Add(transaction);
        //    _context.SaveChanges();
        //}

        public void Add(Transaction transaction)
        {
            if (transaction.TransactionId > 0)
            {
                // If TransactionId is set, enable IDENTITY_INSERT temporarily
                using (var dbTransaction = _context.Database.BeginTransaction())
                {
                    try
                    {
                        _context.Database.ExecuteSqlRaw("SET IDENTITY_INSERT Transactions ON");
                        _context.Transactions.Add(transaction);
                        _context.SaveChanges();
                        _context.Database.ExecuteSqlRaw("SET IDENTITY_INSERT Transactions OFF");
                        dbTransaction.Commit();
                    }
                    catch
                    {
                        dbTransaction.Rollback();
                        throw;
                    }
                }
            }
            else
            {
                // If TransactionId is not set, let the database handle the identity column
                _context.Transactions.Add(transaction);
                _context.SaveChanges();
            }
        }

        Transaction ITransactionsRepository.Get(int id)
        {
            return _context.Transactions.Find(id);
        }

        public void Delete(int id)
        {
            var transactionsToDelete = _context.Transactions.FirstOrDefault(c => c.TransactionId == id);
            if (transactionsToDelete != null)
            {
                _context.Transactions.Remove(transactionsToDelete);
                _context.SaveChanges();
            }
        }

        public IEnumerable<Transaction> GetTransactionsByCustomer(string customerFullName)
        {
            return _context.Transactions
                             .Where(t => t.CustomerFullName == customerFullName)
                             .ToList();
        }

        //get all transactions with filters
        public IEnumerable<Transaction> GetFilteredTransactions(
           string transactionType = null,
           DateTime? startDate = null,
           DateTime? endDate = null,
           string status = null,
           string customerFullName = null,
           decimal? minAmount = null,
           decimal? maxAmount = null)
        {
            var query = _context.Transactions.AsQueryable();

            if (!string.IsNullOrEmpty(transactionType))
            {
                query = query.Where(t => t.TransactionType.Equals(transactionType, StringComparison.OrdinalIgnoreCase));
            }

            if (startDate.HasValue)
            {
                query = query.Where(t => t.TransactionDate >= startDate.Value);
            }

            if (endDate.HasValue)
            {
                query = query.Where(t => t.TransactionDate <= endDate.Value);
            }

            if (!string.IsNullOrEmpty(status))
            {
                query = query.Where(t => t.Status.Equals(status, StringComparison.OrdinalIgnoreCase));
            }

            if (!string.IsNullOrEmpty(customerFullName))
            {
                query = query.Where(t => t.CustomerFullName.Contains(customerFullName, StringComparison.OrdinalIgnoreCase));
            }

            if (minAmount.HasValue)
            {
                query = query.Where(t => t.Amount >= minAmount.Value);
            }

            if (maxAmount.HasValue)
            {
                query = query.Where(t => t.Amount <= maxAmount.Value);
            }

            return query.ToList();
        }
    }
}
    

