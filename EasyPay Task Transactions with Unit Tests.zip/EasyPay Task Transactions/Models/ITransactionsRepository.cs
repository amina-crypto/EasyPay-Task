﻿namespace EasyPay_Task_Transactions.Models
{
    public interface ITransactionsRepository
    {
        void Delete(int id);
        IEnumerable<Transaction> ListAll();
        void Update(Transaction customer);

        void Add(Transaction customer);
        Transaction Get(int id);
        //  a  new json objects that filters in base of the customer 

        IEnumerable<Transaction> GetTransactionsByCustomer(string customerFullName);

        IEnumerable<Transaction> GetFilteredTransactions(
            string transactionType = null,
            DateTime? startDate = null,
            DateTime? endDate = null,
            string status = null,
            string customerFullName = null,
            decimal? minAmount = null,
            decimal? maxAmount = null);
    }

}
