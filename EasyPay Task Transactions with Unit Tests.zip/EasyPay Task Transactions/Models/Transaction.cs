﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EasyPay_Task_Transactions.Models
{
    public class Transaction
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int TransactionId { get; set; } 

        [Required]
        [Column(TypeName = "numeric")]
        public decimal Amount { get; set; } 
        [Required]
        [Column(TypeName = "nvarchar(50)")]
        public string TransactionType { get; set; } // "Credit" or "Debit"

        [Required]
        public DateTime TransactionDate { get; set; } 

        [Column(TypeName = "nvarchar(100)")]
        public string Description { get; set; } 

        [Required]
        [Column(TypeName = "nvarchar(50)")]
        public string Status { get; set; } 

        [Required]
        [Column(TypeName = "nvarchar(50)")]
        public string CustomerFullName { get; set; } 

        [Required]
        [Column(TypeName = "numeric")]
        public decimal CustomerPhoneNumber { get; set; } 

        [Column(TypeName = "nvarchar(100)")]
        public string CustomerAddress { get; set; } 

        [Column(TypeName = "nvarchar(50)")]
        public string CustomerEmailAddress { get; set; } 
    }
}
